export interface Student {
  id: string;
  name: string;
  rank: number;
  score: number;
  avatar: string;
}

export interface Test {
  id: string;
  title: string;
  date: string;
  subject: string;
  totalMarks: number;
  questions: number;
}

export const currentUser = {
  name: "Aditya Kumar",
  grade: "Class 12 - JEE Aspirant",
  avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=60", // Placeholder, will update if generated image is available
};

export const recentTests: Test[] = [
  { id: "t1", title: "JEE Mains Mock Test 4", date: "2024-03-15", subject: "Physics", totalMarks: 300, questions: 75 },
  { id: "t2", title: "Calculus Daily Practice", date: "2024-03-14", subject: "Mathematics", totalMarks: 100, questions: 25 },
  { id: "t3", title: "Organic Chemistry Review", date: "2024-03-12", subject: "Chemistry", totalMarks: 180, questions: 45 },
];

export const leaderboardData: Student[] = [
  { id: "s1", name: "Rahul Sharma", rank: 1, score: 295, avatar: "" },
  { id: "s2", name: "Priya Patel", rank: 2, score: 288, avatar: "" },
  { id: "s3", name: "Amit Singh", rank: 3, score: 285, avatar: "" },
  { id: "s4", name: "Sneha Gupta", rank: 4, score: 280, avatar: "" },
  { id: "s5", name: "Aditya Kumar", rank: 5, score: 276, avatar: "" }, // Current User
  { id: "s6", name: "Vikram Malhotra", rank: 6, score: 272, avatar: "" },
];

export const performanceData = [
  { test: "Mock 1", score: 180, avg: 150 },
  { test: "Mock 2", score: 210, avg: 155 },
  { test: "Mock 3", score: 205, avg: 160 },
  { test: "Mock 4", score: 245, avg: 165 },
  { test: "Mock 5", score: 276, avg: 170 },
];
