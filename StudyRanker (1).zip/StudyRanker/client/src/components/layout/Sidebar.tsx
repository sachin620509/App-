import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { LayoutDashboard, Upload, Trophy, FilePlus, BookOpen, Settings, LogOut, Gamepad2, MessageSquare } from "lucide-react";

export function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", href: "/" },
    { icon: Gamepad2, label: "Quiz Play", href: "/quiz" },
    { icon: Upload, label: "Upload Video", href: "/upload" },
    { icon: Trophy, label: "Test Rankings", href: "/rankings" },
    { icon: FilePlus, label: "Create Worksheet", href: "/create" },
    { icon: MessageSquare, label: "Help & Support", href: "/support" },
    { icon: BookOpen, label: "My Batches", href: "/batches" }, // Placeholder
  ];

  return (
    <div className="h-screen w-64 border-r border-sidebar-border bg-sidebar flex flex-col fixed left-0 top-0 z-30">
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl">
            B
          </div>
          <span className="font-heading font-bold text-lg tracking-tight leading-tight">Bright Study Centre Sadopur</span>
        </div>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-all cursor-pointer group",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-foreground"
                )}
              >
                <Icon className={cn("h-4 w-4", isActive ? "text-primary" : "group-hover:text-primary")} />
                {item.label}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <button className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium text-muted-foreground hover:bg-sidebar-accent/50 hover:text-foreground w-full transition-colors cursor-pointer">
          <Settings className="h-4 w-4" />
          Settings
        </button>
        <button className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium text-destructive hover:bg-destructive/10 w-full transition-colors mt-1 cursor-pointer">
          <LogOut className="h-4 w-4" />
          Logout
        </button>
      </div>
    </div>
  );
}
