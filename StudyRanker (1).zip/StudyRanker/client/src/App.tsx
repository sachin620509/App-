import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AppLayout } from "@/components/layout/AppLayout";
import Dashboard from "@/pages/Dashboard";
import UploadVideo from "@/pages/UploadVideo";
import TestRankings from "@/pages/TestRankings";
import CreateWorksheet from "@/pages/CreateWorksheet";
import QuizPlay from "@/pages/QuizPlay";
import Login from "@/pages/Login";
import SignUp from "@/pages/SignUp";
import ForgotPassword from "@/pages/ForgotPassword";
import QueryResolution from "@/pages/QueryResolution";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/signup" component={SignUp} />
      <Route path="/forgot-password" component={ForgotPassword} />
      <Route>
        <AppLayout>
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/upload" component={UploadVideo} />
            <Route path="/rankings" component={TestRankings} />
            <Route path="/create" component={CreateWorksheet} />
            <Route path="/quiz" component={QuizPlay} />
            <Route path="/support" component={QueryResolution} />
            <Route path="/batches" component={Dashboard} />
            <Route component={NotFound} />
          </Switch>
        </AppLayout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Toaster />
      <Router />
    </QueryClientProvider>
  );
}

export default App;
