import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Timer, CheckCircle2, XCircle, Trophy, ArrowRight, RefreshCcw, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import confetti from "canvas-confetti";

// Mock Quiz Data
const QUIZ_DATA = [
  {
    id: 1,
    question: "What is the SI unit of Force?",
    options: ["Watt", "Pascal", "Newton", "Joule"],
    correctAnswer: 2, // Index of correct option
    explanation: "The SI unit of force is the Newton (N), named after Sir Isaac Newton."
  },
  {
    id: 2,
    question: "Which law states that for every action, there is an equal and opposite reaction?",
    options: ["Newton's First Law", "Newton's Second Law", "Newton's Third Law", "Law of Conservation of Momentum"],
    correctAnswer: 2,
    explanation: "Newton's Third Law states that for every action, there is an equal and opposite reaction."
  },
  {
    id: 3,
    question: "What is the value of acceleration due to gravity (g) on Earth approx?",
    options: ["9.8 m/s²", "8.9 m/s²", "10.8 m/s²", "9.2 m/s²"],
    correctAnswer: 0,
    explanation: "The standard acceleration due to gravity on Earth is approximately 9.8 m/s²."
  },
  {
    id: 4,
    question: "Which of the following is a scalar quantity?",
    options: ["Velocity", "Force", "Displacement", "Speed"],
    correctAnswer: 3,
    explanation: "Speed is a scalar quantity as it has only magnitude, unlike velocity which has both magnitude and direction."
  },
  {
    id: 5,
    question: "Kinetic energy of an object depends on its:",
    options: ["Mass only", "Velocity only", "Mass and Velocity", "Height"],
    correctAnswer: 2,
    explanation: "Kinetic Energy (KE) = 1/2 mv², so it depends on both mass (m) and velocity (v)."
  }
];

export default function QuizPlay() {
  const { toast } = useToast();
  const [isStarted, setIsStarted] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30); // 30 seconds per question
  const [answers, setAnswers] = useState<{questionId: number, selected: number, correct: boolean}[]>([]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isStarted && !isAnswered && !showResults && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && !isAnswered) {
      handleTimeUp();
    }
    return () => clearInterval(timer);
  }, [isStarted, isAnswered, showResults, timeLeft]);

  const handleTimeUp = () => {
    setIsAnswered(true);
    setSelectedOption(-1); // Indicates timeout/no selection
    setAnswers([...answers, { 
      questionId: QUIZ_DATA[currentQuestionIndex].id, 
      selected: -1, 
      correct: false 
    }]);
    toast({
      title: "Time's up!",
      description: "Moving to the next question explanation.",
      variant: "destructive",
    });
  };

  const handleStartQuiz = () => {
    setIsStarted(true);
    setCurrentQuestionIndex(0);
    setScore(0);
    setShowResults(false);
    setAnswers([]);
    resetQuestionState();
  };

  const resetQuestionState = () => {
    setSelectedOption(null);
    setIsAnswered(false);
    setTimeLeft(30);
  };

  const handleOptionSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null) return;

    const isCorrect = selectedOption === QUIZ_DATA[currentQuestionIndex].correctAnswer;
    setIsAnswered(true);
    
    if (isCorrect) {
      setScore((prev) => prev + 1);
      confetti({
        particleCount: 30,
        spread: 60,
        origin: { y: 0.7 },
        disableForReducedMotion: true,
        colors: ['#E11D48', '#FCD34D'] // Primary and Yellow
      });
    }

    setAnswers([...answers, { 
      questionId: QUIZ_DATA[currentQuestionIndex].id, 
      selected: selectedOption, 
      correct: isCorrect 
    }]);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < QUIZ_DATA.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      resetQuestionState();
    } else {
      setShowResults(true);
      if (score > QUIZ_DATA.length / 2) {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
    }
  };

  if (!isStarted) {
    return (
      <div className="max-w-2xl mx-auto mt-10">
        <Card className="text-center border-none shadow-lg overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-2 bg-primary"></div>
          <CardContent className="pt-12 pb-10 px-8 space-y-6">
            <div className="mx-auto bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center mb-4">
              <Trophy className="h-10 w-10 text-primary" />
            </div>
            <div className="space-y-2">
              <h1 className="text-3xl font-heading font-bold">Physics Daily Challenge</h1>
              <p className="text-muted-foreground max-w-md mx-auto">
                Test your knowledge of Newton's Laws and Kinematics. 5 questions, 30 seconds each. Are you ready to top the leaderboard?
              </p>
            </div>
            
            <div className="grid grid-cols-3 gap-4 max-w-sm mx-auto py-6">
              <div className="flex flex-col items-center p-3 bg-secondary/50 rounded-lg">
                <span className="font-bold text-xl">{QUIZ_DATA.length}</span>
                <span className="text-xs text-muted-foreground">Questions</span>
              </div>
              <div className="flex flex-col items-center p-3 bg-secondary/50 rounded-lg">
                <span className="font-bold text-xl">30s</span>
                <span className="text-xs text-muted-foreground">Per Q</span>
              </div>
              <div className="flex flex-col items-center p-3 bg-secondary/50 rounded-lg">
                <span className="font-bold text-xl">+4/-1</span>
                <span className="text-xs text-muted-foreground">Marking</span>
              </div>
            </div>

            <Button size="lg" onClick={handleStartQuiz} className="w-full max-w-xs text-lg h-12 shadow-lg shadow-primary/20 hover:scale-105 transition-transform">
              Start Quiz
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showResults) {
    const percentage = Math.round((score / QUIZ_DATA.length) * 100);
    
    return (
      <div className="max-w-2xl mx-auto mt-8 space-y-6">
        <Card className="border-none shadow-lg overflow-hidden">
          <CardHeader className="bg-primary/5 border-b border-border pb-8 text-center">
            <div className="mx-auto w-24 h-24 flex items-center justify-center rounded-full bg-background border-4 border-primary mb-4 shadow-sm">
              <span className="text-3xl font-bold text-primary">{percentage}%</span>
            </div>
            <CardTitle className="text-2xl mb-1">Quiz Completed!</CardTitle>
            <p className="text-muted-foreground">
              You scored {score} out of {QUIZ_DATA.length}
            </p>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            <div className="space-y-4">
              <h3 className="font-bold text-lg">Review Answers</h3>
              {QUIZ_DATA.map((q, idx) => {
                const userAnswer = answers.find(a => a.questionId === q.id);
                const isCorrect = userAnswer?.correct;
                
                return (
                  <div key={q.id} className="p-4 rounded-lg border bg-card/50">
                    <div className="flex gap-3">
                      <div className="mt-1">
                        {isCorrect ? (
                          <CheckCircle2 className="h-5 w-5 text-green-500" />
                        ) : (
                          <XCircle className="h-5 w-5 text-destructive" />
                        )}
                      </div>
                      <div className="space-y-2 w-full">
                        <p className="font-medium text-sm">{idx + 1}. {q.question}</p>
                        <div className="text-sm space-y-1">
                          <p className={cn("flex items-center gap-2", isCorrect ? "text-green-600 font-medium" : "text-destructive")}>
                            Your Answer: {userAnswer?.selected === -1 ? "Time out" : q.options[userAnswer?.selected as number]}
                          </p>
                          {!isCorrect && (
                            <p className="text-green-600 font-medium flex items-center gap-2">
                              Correct Answer: {q.options[q.correctAnswer]}
                            </p>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground bg-secondary/50 p-2 rounded mt-2">
                          <span className="font-bold">Explanation:</span> {q.explanation}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
          <CardFooter className="bg-secondary/20 p-6 flex justify-center gap-4">
            <Button variant="outline" onClick={handleStartQuiz}>
              <RefreshCcw className="mr-2 h-4 w-4" /> Retry Quiz
            </Button>
            <Button onClick={() => setIsStarted(false)}>
              Back to Home
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  const currentQuestion = QUIZ_DATA[currentQuestionIndex];

  return (
    <div className="max-w-3xl mx-auto mt-4 space-y-6">
      {/* Header with Progress and Timer */}
      <div className="flex items-center justify-between gap-4 bg-card p-4 rounded-xl shadow-sm border border-border">
        <div className="flex flex-col gap-1 w-full max-w-[200px]">
          <div className="flex justify-between text-xs font-medium text-muted-foreground">
            <span>Question {currentQuestionIndex + 1}/{QUIZ_DATA.length}</span>
            <span>{Math.round(((currentQuestionIndex) / QUIZ_DATA.length) * 100)}%</span>
          </div>
          <Progress value={((currentQuestionIndex + 1) / QUIZ_DATA.length) * 100} className="h-2" />
        </div>
        
        <div className={cn(
          "flex items-center gap-2 px-4 py-2 rounded-full font-mono font-bold border transition-colors",
          timeLeft <= 10 ? "bg-destructive/10 text-destructive border-destructive/20 animate-pulse" : "bg-secondary text-foreground border-transparent"
        )}>
          <Timer className="h-4 w-4" />
          <span>00:{timeLeft.toString().padStart(2, '0')}</span>
        </div>
      </div>

      {/* Question Card */}
      <Card className="border-none shadow-md overflow-hidden">
        <CardContent className="p-6 md:p-8 space-y-8">
          <div className="space-y-4">
            <h2 className="text-xl md:text-2xl font-bold font-heading leading-relaxed">
              {currentQuestion.question}
            </h2>
          </div>

          <RadioGroup value={selectedOption?.toString()} className="space-y-3">
            {currentQuestion.options.map((option, index) => {
              let optionStyle = "border-border hover:bg-secondary/50 hover:border-primary/50";
              
              if (isAnswered) {
                if (index === currentQuestion.correctAnswer) {
                  optionStyle = "border-green-500 bg-green-50 dark:bg-green-950/30 ring-1 ring-green-500";
                } else if (index === selectedOption) {
                  optionStyle = "border-destructive bg-destructive/5 ring-1 ring-destructive";
                } else {
                  optionStyle = "opacity-50";
                }
              } else if (selectedOption === index) {
                optionStyle = "border-primary bg-primary/5 ring-1 ring-primary";
              }

              return (
                <div key={index} 
                  className={cn(
                    "flex items-center space-x-3 rounded-xl border p-4 cursor-pointer transition-all duration-200",
                    optionStyle
                  )}
                  onClick={() => handleOptionSelect(index)}
                >
                  <RadioGroupItem value={index.toString()} id={`option-${index}`} className="sr-only" />
                  <div className={cn(
                    "h-6 w-6 rounded-full border flex items-center justify-center flex-shrink-0",
                    isAnswered && index === currentQuestion.correctAnswer ? "border-green-500 bg-green-500 text-white" :
                    isAnswered && index === selectedOption ? "border-destructive bg-destructive text-white" :
                    selectedOption === index ? "border-primary bg-primary text-white" : "border-muted-foreground"
                  )}>
                     {isAnswered && index === currentQuestion.correctAnswer ? <CheckCircle2 className="h-4 w-4" /> : 
                      isAnswered && index === selectedOption ? <XCircle className="h-4 w-4" /> :
                      <span className="text-xs font-medium">{String.fromCharCode(65 + index)}</span>}
                  </div>
                  <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer font-medium text-base">
                    {option}
                  </Label>
                </div>
              );
            })}
          </RadioGroup>

          {isAnswered && (
            <div className="bg-secondary/30 rounded-lg p-4 border border-border animate-in fade-in slide-in-from-top-2">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <p className="font-bold text-sm text-primary mb-1">Explanation</p>
                  <p className="text-sm text-muted-foreground leading-relaxed">{currentQuestion.explanation}</p>
                </div>
              </div>
            </div>
          )}

        </CardContent>
        <CardFooter className="bg-secondary/10 p-6 flex justify-end border-t border-border">
          {!isAnswered ? (
            <Button 
              size="lg" 
              onClick={handleSubmitAnswer} 
              disabled={selectedOption === null}
              className="w-full md:w-auto min-w-[140px] shadow-lg shadow-primary/20"
            >
              Submit Answer
            </Button>
          ) : (
            <Button 
              size="lg" 
              onClick={handleNextQuestion}
              className="w-full md:w-auto min-w-[140px] group"
            >
              {currentQuestionIndex < QUIZ_DATA.length - 1 ? "Next Question" : "Finish Quiz"}
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}
