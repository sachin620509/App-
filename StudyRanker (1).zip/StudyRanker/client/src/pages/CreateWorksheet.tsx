import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Save, FileCheck, GripVertical } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";

interface Question {
  id: number;
  text: string;
  options: string[];
  correctOption: number;
}

export default function CreateWorksheet() {
  const { toast } = useToast();
  const [questions, setQuestions] = useState<Question[]>([
    { id: 1, text: "", options: ["", "", "", ""], correctOption: 0 }
  ]);

  const addQuestion = () => {
    setQuestions([
      ...questions, 
      { id: questions.length + 1, text: "", options: ["", "", "", ""], correctOption: 0 }
    ]);
  };

  const removeQuestion = (index: number) => {
    if (questions.length === 1) return;
    const newQuestions = [...questions];
    newQuestions.splice(index, 1);
    setQuestions(newQuestions);
  };

  const updateQuestionText = (index: number, text: string) => {
    const newQuestions = [...questions];
    newQuestions[index].text = text;
    setQuestions(newQuestions);
  };

  const updateOption = (qIndex: number, oIndex: number, text: string) => {
    const newQuestions = [...questions];
    newQuestions[qIndex].options[oIndex] = text;
    setQuestions(newQuestions);
  };

  const setCorrectOption = (qIndex: number, oIndex: number) => {
    const newQuestions = [...questions];
    newQuestions[qIndex].correctOption = oIndex;
    setQuestions(newQuestions);
  };

  const handleSave = () => {
    toast({
      title: "Worksheet Created",
      description: `Successfully created worksheet with ${questions.length} questions.`,
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold mb-2">Create Test Worksheet</h1>
          <p className="text-muted-foreground">Design a new test or worksheet for your students.</p>
        </div>
        <Button onClick={handleSave} size="lg" className="shadow-lg shadow-primary/20">
          <Save className="mr-2 h-4 w-4" /> Publish Test
        </Button>
      </div>

      <Card className="border-none shadow-md">
        <CardHeader>
          <CardTitle>Test Details</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="test-title">Test Title</Label>
            <Input id="test-title" placeholder="e.g., Kinetic Energy Quiz" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="test-subject">Subject</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Select Subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="physics">Physics</SelectItem>
                <SelectItem value="math">Mathematics</SelectItem>
                <SelectItem value="chemistry">Chemistry</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="test-duration">Duration (minutes)</Label>
            <Input id="test-duration" type="number" placeholder="60" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="test-marks">Total Marks</Label>
            <Input id="test-marks" type="number" placeholder="100" />
          </div>
        </CardContent>
      </Card>

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <FileCheck className="h-5 w-5 text-primary" /> 
            Questions ({questions.length})
          </h2>
        </div>

        {questions.map((q, qIndex) => (
          <Card key={qIndex} className="border-none shadow-sm relative group hover:shadow-md transition-shadow">
            <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary/50 rounded-l-lg group-hover:bg-primary transition-colors" />
            <CardContent className="pt-6 pl-6">
              <div className="flex gap-4">
                <div className="mt-2 text-muted-foreground cursor-grab active:cursor-grabbing">
                  <GripVertical className="h-5 w-5" />
                </div>
                <div className="flex-1 space-y-4">
                  <div className="flex justify-between items-start gap-4">
                    <div className="w-full space-y-2">
                      <Label className="text-base">Question {qIndex + 1}</Label>
                      <Textarea 
                        placeholder="Enter your question text here..." 
                        value={q.text}
                        onChange={(e) => updateQuestionText(qIndex, e.target.value)}
                        className="resize-none bg-secondary/20"
                      />
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-muted-foreground hover:text-destructive"
                      onClick={() => removeQuestion(qIndex)}
                      disabled={questions.length === 1}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {q.options.map((opt, oIndex) => (
                      <div key={oIndex} className="flex items-center gap-3">
                        <div 
                          className={cn(
                            "h-6 w-6 rounded-full border flex items-center justify-center cursor-pointer transition-colors",
                            q.correctOption === oIndex 
                              ? "bg-primary border-primary text-primary-foreground" 
                              : "border-muted-foreground hover:border-primary text-transparent"
                          )}
                          onClick={() => setCorrectOption(qIndex, oIndex)}
                        >
                          <div className="h-2 w-2 bg-current rounded-full" />
                        </div>
                        <Input 
                          placeholder={`Option ${oIndex + 1}`} 
                          value={opt}
                          onChange={(e) => updateOption(qIndex, oIndex, e.target.value)}
                          className={cn(
                            q.correctOption === oIndex ? "border-primary bg-primary/5" : ""
                          )}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        <Button 
          variant="outline" 
          className="w-full border-dashed border-2 h-12 hover:border-primary hover:text-primary hover:bg-primary/5"
          onClick={addQuestion}
        >
          <Plus className="mr-2 h-4 w-4" /> Add New Question
        </Button>
      </div>
    </div>
  );
}
