import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { leaderboardData, currentUser } from "@/lib/mockData";
import { Trophy, Medal, Crown, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function TestRankings() {
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="h-5 w-5 text-yellow-500" fill="currentColor" />;
      case 2: return <Medal className="h-5 w-5 text-gray-400" fill="currentColor" />;
      case 3: return <Medal className="h-5 w-5 text-amber-700" fill="currentColor" />;
      default: return <span className="font-bold text-muted-foreground w-5 text-center">{rank}</span>;
    }
  };

  const getRowStyle = (rank: number) => {
    switch (rank) {
      case 1: return "bg-yellow-500/10 border-l-4 border-l-yellow-500";
      case 2: return "bg-gray-400/10 border-l-4 border-l-gray-400";
      case 3: return "bg-amber-700/10 border-l-4 border-l-amber-700";
      default: return "";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold mb-2">Test Leaderboard</h1>
          <p className="text-muted-foreground">Rankings for JEE Mains Mock Test 4</p>
        </div>
        <div className="relative w-full md:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search student..." className="pl-9" />
        </div>
      </div>

      {/* Top 3 Cards - Mobile/Tablet View */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {[leaderboardData[1], leaderboardData[0], leaderboardData[2]].map((student, index) => (
          <Card key={student.id} className={cn(
            "border-none shadow-md relative overflow-hidden", 
            student.rank === 1 ? "md:-mt-8 z-10 ring-2 ring-yellow-500 bg-yellow-50/50 dark:bg-yellow-950/20" : "bg-card"
          )}>
            <div className={cn("absolute top-0 left-0 w-full h-1", 
              student.rank === 1 ? "bg-yellow-500" : student.rank === 2 ? "bg-gray-400" : "bg-amber-700"
            )} />
            <CardContent className="pt-8 text-center flex flex-col items-center">
              <div className="relative mb-4">
                <Avatar className="h-20 w-20 border-4 border-background shadow-lg">
                  <AvatarImage src={student.avatar} />
                  <AvatarFallback className="text-lg">{student.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className={cn(
                  "absolute -bottom-3 left-1/2 -translate-x-1/2 rounded-full p-1.5 shadow-sm border-2 border-background",
                  student.rank === 1 ? "bg-yellow-100 text-yellow-600" : 
                  student.rank === 2 ? "bg-gray-100 text-gray-600" : 
                  "bg-amber-100 text-amber-700"
                )}>
                  {student.rank === 1 ? <Crown className="h-4 w-4 fill-current" /> : <Medal className="h-4 w-4 fill-current" />}
                </div>
              </div>
              <h3 className="font-bold text-lg">{student.name}</h3>
              <div className="mt-2 text-3xl font-bold tracking-tighter text-primary">{student.score}<span className="text-sm font-normal text-muted-foreground ml-1">/ 300</span></div>
              <p className="text-xs text-muted-foreground mt-1">Rank #{student.rank}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-none shadow-sm overflow-hidden">
        <CardHeader className="bg-secondary/30 border-b border-border">
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-primary" />
            All Rankings
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[80px] text-center">Rank</TableHead>
                <TableHead>Student</TableHead>
                <TableHead className="text-right">Score</TableHead>
                <TableHead className="text-right">Percentile</TableHead>
                <TableHead className="w-[100px] text-center">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leaderboardData.map((student) => (
                <TableRow key={student.id} className={cn(
                    getRowStyle(student.rank), 
                    student.name === currentUser.name ? "bg-primary/5" : ""
                  )}>
                  <TableCell className="font-medium text-center">
                    <div className="flex justify-center">{getRankIcon(student.rank)}</div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={student.avatar} />
                        <AvatarFallback>{student.name.substring(0, 2)}</AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col">
                        <span className={cn("font-medium", student.name === currentUser.name && "text-primary font-bold")}>
                          {student.name} {student.name === currentUser.name && "(You)"}
                        </span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-bold">{student.score}</TableCell>
                  <TableCell className="text-right text-muted-foreground">
                    {((student.score / 300) * 100).toFixed(1)}%
                  </TableCell>
                  <TableCell className="text-center">
                    {student.score >= 280 ? (
                      <Badge className="bg-green-500 hover:bg-green-600">Excellent</Badge>
                    ) : student.score >= 250 ? (
                      <Badge className="bg-blue-500 hover:bg-blue-600">Good</Badge>
                    ) : (
                      <Badge variant="outline">Average</Badge>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// Helper for class merging in map
import { cn } from "@/lib/utils";
