import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MessageSquare, Plus, Send, Clock, CheckCircle2, AlertCircle, Search, Paperclip, FileText } from "lucide-react";
import { cn } from "@/lib/utils";
import { currentUser } from "@/lib/mockData";

interface Query {
  id: string;
  subject: string;
  title: string;
  status: "pending" | "resolved" | "in-progress";
  date: string;
  lastMessage: string;
  messages: {
    id: number;
    sender: "user" | "admin";
    text: string;
    timestamp: string;
  }[];
}

const MOCK_QUERIES: Query[] = [
  {
    id: "q1",
    subject: "Physics",
    title: "Doubt in Rotational Motion Q4",
    status: "resolved",
    date: "2025-11-28",
    lastMessage: "The solution has been attached.",
    messages: [
      { id: 1, sender: "user", text: "I'm unable to solve Q4 from the latest worksheet. Can you help?", timestamp: "10:30 AM" },
      { id: 2, sender: "admin", text: "Sure! The key is to apply conservation of angular momentum. Here is the solution.", timestamp: "11:15 AM" },
      { id: 3, sender: "user", text: "Got it! Thanks sir.", timestamp: "11:20 AM" }
    ]
  },
  {
    id: "q2",
    subject: "Mathematics",
    title: "Integration by Parts confusion",
    status: "in-progress",
    date: "2025-11-29",
    lastMessage: "Checking with the faculty.",
    messages: [
      { id: 1, sender: "user", text: "When exactly should I use the ILATE rule?", timestamp: "09:00 AM" },
      { id: 2, sender: "admin", text: "Let me connect you with the Maths faculty for a detailed explanation.", timestamp: "09:30 AM" }
    ]
  },
  {
    id: "q3",
    subject: "Administration",
    title: "Test Schedule Change Request",
    status: "pending",
    date: "2025-11-29",
    lastMessage: "Request received.",
    messages: [
      { id: 1, sender: "user", text: "I have a family function on Sunday. Can I take the test on Monday?", timestamp: "2:00 PM" }
    ]
  }
];

export default function QueryResolution() {
  const [queries, setQueries] = useState<Query[]>(MOCK_QUERIES);
  const [selectedQueryId, setSelectedQueryId] = useState<string | null>(MOCK_QUERIES[0].id);
  const [newMessage, setNewMessage] = useState("");
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  const selectedQuery = queries.find(q => q.id === selectedQueryId);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved": return "bg-green-500/10 text-green-600 border-green-200";
      case "in-progress": return "bg-blue-500/10 text-blue-600 border-blue-200";
      default: return "bg-yellow-500/10 text-yellow-600 border-yellow-200";
    }
  };

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedQueryId) return;

    const updatedQueries = queries.map(q => {
      if (q.id === selectedQueryId) {
        return {
          ...q,
          lastMessage: newMessage,
          messages: [
            ...q.messages,
            {
              id: q.messages.length + 1,
              sender: "user" as const,
              text: newMessage,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            }
          ]
        };
      }
      return q;
    });

    setQueries(updatedQueries);
    setNewMessage("");
  };

  return (
    <div className="h-[calc(100vh-6rem)] flex flex-col space-y-4">
      <div>
        <h1 className="text-3xl font-heading font-bold mb-2">Student Help Desk</h1>
        <p className="text-muted-foreground">Raise queries and get solutions from faculty.</p>
      </div>

      <div className="flex-1 flex gap-6 h-full overflow-hidden">
        {/* Left Sidebar - Query List */}
        <div className="w-full md:w-1/3 flex flex-col gap-4 bg-card rounded-xl border shadow-sm overflow-hidden">
          <div className="p-4 border-b space-y-4">
            <Button 
              className="w-full shadow-md" 
              onClick={() => { setIsCreatingNew(true); setSelectedQueryId(null); }}
            >
              <Plus className="mr-2 h-4 w-4" /> New Query
            </Button>
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search queries..." className="pl-9 bg-secondary/50" />
            </div>
          </div>
          <ScrollArea className="flex-1">
            <div className="flex flex-col p-2 gap-2">
              {queries.map((query) => (
                <button
                  key={query.id}
                  onClick={() => { setSelectedQueryId(query.id); setIsCreatingNew(false); }}
                  className={cn(
                    "flex flex-col items-start gap-2 p-4 rounded-lg transition-all text-left border",
                    selectedQueryId === query.id 
                      ? "bg-primary/5 border-primary/20 shadow-sm" 
                      : "bg-transparent border-transparent hover:bg-secondary/50"
                  )}
                >
                  <div className="flex w-full justify-between items-start">
                    <span className="font-semibold text-sm line-clamp-1">{query.title}</span>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">{query.date}</span>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2 w-full">
                    {query.lastMessage}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className={cn("text-[10px] px-2 py-0 h-5", getStatusColor(query.status))}>
                      {query.status.replace("-", " ")}
                    </Badge>
                    <Badge variant="secondary" className="text-[10px] px-2 py-0 h-5 text-muted-foreground">
                      {query.subject}
                    </Badge>
                  </div>
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Right Side - Chat Area or New Form */}
        <div className="flex-1 bg-card rounded-xl border shadow-sm overflow-hidden flex flex-col">
          {isCreatingNew ? (
            <div className="p-8 max-w-2xl mx-auto w-full flex flex-col justify-center h-full space-y-6">
              <div className="text-center space-y-2">
                <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <MessageSquare className="h-6 w-6 text-primary" />
                </div>
                <h2 className="text-2xl font-bold">Submit a New Query</h2>
                <p className="text-muted-foreground">Describe your issue or doubt clearly.</p>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Subject</label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Select Subject" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="physics">Physics</SelectItem>
                      <SelectItem value="maths">Mathematics</SelectItem>
                      <SelectItem value="chemistry">Chemistry</SelectItem>
                      <SelectItem value="admin">Administration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Title</label>
                  <Input placeholder="Brief summary of your query" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <Textarea placeholder="Explain in detail..." className="min-h-[150px]" />
                </div>
                <div className="pt-4 flex gap-4 justify-end">
                  <Button variant="ghost" onClick={() => setIsCreatingNew(false)}>Cancel</Button>
                  <Button onClick={() => setIsCreatingNew(false)}>Submit Query</Button>
                </div>
              </div>
            </div>
          ) : selectedQuery ? (
            <>
              {/* Chat Header */}
              <div className="p-4 border-b flex items-center justify-between bg-card z-10 shadow-sm">
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <FileText className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h2 className="font-bold text-lg leading-none">{selectedQuery.title}</h2>
                    <p className="text-xs text-muted-foreground mt-1">Ticket ID: #{selectedQuery.id}</p>
                  </div>
                </div>
                <Badge className={cn(getStatusColor(selectedQuery.status))}>
                  {selectedQuery.status}
                </Badge>
              </div>

              {/* Chat Messages */}
              <ScrollArea className="flex-1 p-4 bg-secondary/20">
                <div className="space-y-6 max-w-3xl mx-auto">
                  <div className="text-center text-xs text-muted-foreground my-4">
                    Ticket Created on {selectedQuery.date}
                  </div>
                  
                  {selectedQuery.messages.map((msg) => (
                    <div 
                      key={msg.id} 
                      className={cn(
                        "flex gap-3 max-w-[80%]",
                        msg.sender === "user" ? "ml-auto flex-row-reverse" : ""
                      )}
                    >
                      <Avatar className="h-8 w-8 border">
                         {msg.sender === "user" ? (
                           <>
                             <AvatarImage src={currentUser.avatar} />
                             <AvatarFallback>ME</AvatarFallback>
                           </>
                         ) : (
                           <AvatarFallback className="bg-primary text-primary-foreground">AD</AvatarFallback>
                         )}
                      </Avatar>
                      <div className={cn(
                        "p-3 rounded-lg shadow-sm text-sm",
                        msg.sender === "user" 
                          ? "bg-primary text-primary-foreground rounded-tr-none" 
                          : "bg-white dark:bg-card border rounded-tl-none"
                      )}>
                        <p>{msg.text}</p>
                        <p className={cn(
                          "text-[10px] mt-1 text-right opacity-70",
                          msg.sender === "user" ? "text-primary-foreground" : "text-muted-foreground"
                        )}>{msg.timestamp}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              {/* Chat Input */}
              <div className="p-4 bg-background border-t">
                <div className="flex items-center gap-2 max-w-3xl mx-auto">
                  <Button size="icon" variant="ghost" className="flex-shrink-0 text-muted-foreground">
                    <Paperclip className="h-5 w-5" />
                  </Button>
                  <Input 
                    placeholder="Type your reply..." 
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="flex-1"
                  />
                  <Button size="icon" onClick={handleSendMessage} className="flex-shrink-0 shadow-sm">
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground flex-col gap-4">
              <MessageSquare className="h-12 w-12 opacity-20" />
              <p>Select a query to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
