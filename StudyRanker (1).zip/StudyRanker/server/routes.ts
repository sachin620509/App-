import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import { insertUserSchema, insertQuizAttemptSchema, insertSupportQuerySchema, insertVideoUploadSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Authentication routes
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const { name, email, password, grade } = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: "Email already registered" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Create user
      const user = await storage.createUser({
        name,
        email,
        password: hashedPassword,
        grade,
        avatar: null,
      });
      
      // Store user session
      (req.session as any).userId = user.id;
      
      // Don't send password back
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Signup error:", error);
      res.status(400).json({ error: "Invalid input" });
    }
  });
  
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password required" });
      }
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Store user session
      (req.session as any).userId = user.id;
      
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });
  
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ success: true });
    });
  });
  
  app.get("/api/auth/me", async (req, res) => {
    const userId = (req.session as any).userId;
    if (!userId) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    const { password: _, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });
  
  // Quiz routes
  app.get("/api/quiz/questions", async (req, res) => {
    try {
      const subject = req.query.subject as string | undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      
      const questions = await storage.getQuizQuestions(subject, limit);
      
      // Don't send correct answers to client
      const questionsWithoutAnswers = questions.map(q => ({
        id: q.id,
        subject: q.subject,
        question: q.question,
        options: q.options,
        difficulty: q.difficulty,
      }));
      
      res.json(questionsWithoutAnswers);
    } catch (error) {
      console.error("Get quiz questions error:", error);
      res.status(500).json({ error: "Failed to fetch questions" });
    }
  });
  
  app.post("/api/quiz/submit", async (req, res) => {
    try {
      const userId = (req.session as any).userId;
      if (!userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const { answers, score, totalQuestions } = req.body;
      
      const attempt = await storage.saveQuizAttempt({
        userId,
        score,
        totalQuestions,
        answers,
      });
      
      res.json(attempt);
    } catch (error) {
      console.error("Submit quiz error:", error);
      res.status(500).json({ error: "Failed to submit quiz" });
    }
  });
  
  app.get("/api/quiz/attempts", async (req, res) => {
    try {
      const userId = (req.session as any).userId;
      if (!userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const attempts = await storage.getUserQuizAttempts(userId);
      res.json(attempts);
    } catch (error) {
      console.error("Get quiz attempts error:", error);
      res.status(500).json({ error: "Failed to fetch attempts" });
    }
  });
  
  // Test/Worksheet routes
  app.get("/api/tests", async (req, res) => {
    try {
      const tests = await storage.getTests();
      res.json(tests);
    } catch (error) {
      console.error("Get tests error:", error);
      res.status(500).json({ error: "Failed to fetch tests" });
    }
  });
  
  app.get("/api/tests/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const test = await storage.getTest(id);
      
      if (!test) {
        return res.status(404).json({ error: "Test not found" });
      }
      
      res.json(test);
    } catch (error) {
      console.error("Get test error:", error);
      res.status(500).json({ error: "Failed to fetch test" });
    }
  });
  
  app.get("/api/tests/:id/rankings", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const results = await storage.getTestResults(id);
      
      // Format as rankings
      const rankings = results.map((result, index) => ({
        rank: index + 1,
        studentName: result.userName,
        userId: result.userId,
        score: result.score,
        totalMarks: result.totalMarks,
        percentage: Math.round((result.score / result.totalMarks) * 100),
      }));
      
      res.json(rankings);
    } catch (error) {
      console.error("Get test rankings error:", error);
      res.status(500).json({ error: "Failed to fetch rankings" });
    }
  });
  
  app.get("/api/performance", async (req, res) => {
    try {
      const userId = (req.session as any).userId;
      if (!userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const testResults = await storage.getUserTestResults(userId);
      const quizAttempts = await storage.getUserQuizAttempts(userId, 20);
      
      res.json({
        testResults,
        quizAttempts,
      });
    } catch (error) {
      console.error("Get performance error:", error);
      res.status(500).json({ error: "Failed to fetch performance data" });
    }
  });
  
  // Support Query routes
  app.get("/api/queries", async (req, res) => {
    try {
      const userId = (req.session as any).userId;
      if (!userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const queries = await storage.getSupportQueries(userId);
      res.json(queries);
    } catch (error) {
      console.error("Get queries error:", error);
      res.status(500).json({ error: "Failed to fetch queries" });
    }
  });
  
  app.get("/api/queries/:id", async (req, res) => {
    try {
      const userId = (req.session as any).userId;
      if (!userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const id = parseInt(req.params.id);
      const query = await storage.getSupportQuery(id);
      
      if (!query) {
        return res.status(404).json({ error: "Query not found" });
      }
      
      // Ensure user owns this query
      if (query.userId !== userId) {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      res.json(query);
    } catch (error) {
      console.error("Get query error:", error);
      res.status(500).json({ error: "Failed to fetch query" });
    }
  });
  
  app.post("/api/queries", async (req, res) => {
    try {
      const userId = (req.session as any).userId;
      if (!userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const { subject, title, messages } = insertSupportQuerySchema.parse(req.body);
      
      const query = await storage.createSupportQuery({
        userId,
        subject,
        title,
        status: "pending",
        messages,
      });
      
      res.json(query);
    } catch (error) {
      console.error("Create query error:", error);
      res.status(400).json({ error: "Failed to create query" });
    }
  });
  
  app.patch("/api/queries/:id", async (req, res) => {
    try {
      const userId = (req.session as any).userId;
      if (!userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const id = parseInt(req.params.id);
      const query = await storage.getSupportQuery(id);
      
      if (!query) {
        return res.status(404).json({ error: "Query not found" });
      }
      
      if (query.userId !== userId) {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const updated = await storage.updateSupportQuery(id, req.body);
      res.json(updated);
    } catch (error) {
      console.error("Update query error:", error);
      res.status(500).json({ error: "Failed to update query" });
    }
  });
  
  // Video Upload routes
  app.post("/api/videos", async (req, res) => {
    try {
      const userId = (req.session as any).userId;
      if (!userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const videoData = insertVideoUploadSchema.parse({
        ...req.body,
        userId,
      });
      
      const video = await storage.createVideoUpload(videoData);
      res.json(video);
    } catch (error) {
      console.error("Create video upload error:", error);
      res.status(400).json({ error: "Failed to create video upload" });
    }
  });
  
  app.get("/api/videos", async (req, res) => {
    try {
      const userId = (req.session as any).userId;
      if (!userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const videos = await storage.getUserVideoUploads(userId);
      res.json(videos);
    } catch (error) {
      console.error("Get videos error:", error);
      res.status(500).json({ error: "Failed to fetch videos" });
    }
  });

  return httpServer;
}
