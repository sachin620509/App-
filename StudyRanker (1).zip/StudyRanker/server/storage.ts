import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool } from "@neondatabase/serverless";
import { 
  users, 
  quizQuestions, 
  quizAttempts, 
  tests, 
  testResults, 
  supportQueries, 
  videoUploads,
  type User, 
  type InsertUser, 
  type QuizQuestion, 
  type InsertQuizQuestion, 
  type QuizAttempt, 
  type InsertQuizAttempt,
  type Test,
  type InsertTest,
  type TestResult,
  type InsertTestResult,
  type SupportQuery,
  type InsertSupportQuery,
  type VideoUpload,
  type InsertVideoUpload
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Quiz operations
  getQuizQuestions(subject?: string, limit?: number): Promise<QuizQuestion[]>;
  createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion>;
  saveQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
  getUserQuizAttempts(userId: string, limit?: number): Promise<QuizAttempt[]>;
  
  // Test/Worksheet operations
  getTests(): Promise<Test[]>;
  getTest(id: number): Promise<Test | undefined>;
  createTest(test: InsertTest): Promise<Test>;
  saveTestResult(result: InsertTestResult): Promise<TestResult>;
  getTestResults(testId: number): Promise<Array<TestResult & { userName: string }>>;
  getUserTestResults(userId: string): Promise<TestResult[]>;
  
  // Support Query operations
  getSupportQueries(userId: string): Promise<SupportQuery[]>;
  getSupportQuery(id: number): Promise<SupportQuery | undefined>;
  createSupportQuery(query: InsertSupportQuery): Promise<SupportQuery>;
  updateSupportQuery(id: number, updates: Partial<SupportQuery>): Promise<SupportQuery | undefined>;
  
  // Video Upload operations
  createVideoUpload(upload: InsertVideoUpload): Promise<VideoUpload>;
  getUserVideoUploads(userId: string): Promise<VideoUpload[]>;
}

export class DatabaseStorage implements IStorage {
  private db;

  constructor() {
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    this.db = drizzle(pool);
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await this.db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // Quiz operations
  async getQuizQuestions(subject?: string, limit: number = 5): Promise<QuizQuestion[]> {
    let query = this.db.select().from(quizQuestions);
    
    if (subject) {
      query = query.where(eq(quizQuestions.subject, subject)) as any;
    }
    
    return await query.limit(limit);
  }

  async createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion> {
    const result = await this.db.insert(quizQuestions).values(question).returning();
    return result[0];
  }

  async saveQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const result = await this.db.insert(quizAttempts).values(attempt).returning();
    return result[0];
  }

  async getUserQuizAttempts(userId: string, limit: number = 10): Promise<QuizAttempt[]> {
    return await this.db
      .select()
      .from(quizAttempts)
      .where(eq(quizAttempts.userId, userId))
      .orderBy(desc(quizAttempts.completedAt))
      .limit(limit);
  }

  // Test/Worksheet operations
  async getTests(): Promise<Test[]> {
    return await this.db.select().from(tests).orderBy(desc(tests.createdAt));
  }

  async getTest(id: number): Promise<Test | undefined> {
    const result = await this.db.select().from(tests).where(eq(tests.id, id));
    return result[0];
  }

  async createTest(test: InsertTest): Promise<Test> {
    const result = await this.db.insert(tests).values(test).returning();
    return result[0];
  }

  async saveTestResult(result: InsertTestResult): Promise<TestResult> {
    const inserted = await this.db.insert(testResults).values(result).returning();
    return inserted[0];
  }

  async getTestResults(testId: number): Promise<Array<TestResult & { userName: string }>> {
    const results = await this.db
      .select({
        id: testResults.id,
        testId: testResults.testId,
        userId: testResults.userId,
        score: testResults.score,
        totalMarks: testResults.totalMarks,
        answers: testResults.answers,
        completedAt: testResults.completedAt,
        userName: users.name,
      })
      .from(testResults)
      .leftJoin(users, eq(testResults.userId, users.id))
      .where(eq(testResults.testId, testId))
      .orderBy(desc(testResults.score));
    
    return results as Array<TestResult & { userName: string }>;
  }

  async getUserTestResults(userId: string): Promise<TestResult[]> {
    return await this.db
      .select()
      .from(testResults)
      .where(eq(testResults.userId, userId))
      .orderBy(desc(testResults.completedAt));
  }

  // Support Query operations
  async getSupportQueries(userId: string): Promise<SupportQuery[]> {
    return await this.db
      .select()
      .from(supportQueries)
      .where(eq(supportQueries.userId, userId))
      .orderBy(desc(supportQueries.updatedAt));
  }

  async getSupportQuery(id: number): Promise<SupportQuery | undefined> {
    const result = await this.db.select().from(supportQueries).where(eq(supportQueries.id, id));
    return result[0];
  }

  async createSupportQuery(query: InsertSupportQuery): Promise<SupportQuery> {
    const result = await this.db.insert(supportQueries).values(query).returning();
    return result[0];
  }

  async updateSupportQuery(id: number, updates: Partial<SupportQuery>): Promise<SupportQuery | undefined> {
    const result = await this.db
      .update(supportQueries)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(supportQueries.id, id))
      .returning();
    return result[0];
  }

  // Video Upload operations
  async createVideoUpload(upload: InsertVideoUpload): Promise<VideoUpload> {
    const result = await this.db.insert(videoUploads).values(upload).returning();
    return result[0];
  }

  async getUserVideoUploads(userId: string): Promise<VideoUpload[]> {
    return await this.db
      .select()
      .from(videoUploads)
      .where(eq(videoUploads.userId, userId))
      .orderBy(desc(videoUploads.uploadedAt));
  }
}

export const storage = new DatabaseStorage();
